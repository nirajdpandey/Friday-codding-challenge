#!/bin/bash

#########################################
# Installing necessary packages and running the project
# pyYaml
#########################################

# You can install other packages using pip
# However, there is already a requirements file which take cares of it
pip install -r requirements.txt
python main.py
